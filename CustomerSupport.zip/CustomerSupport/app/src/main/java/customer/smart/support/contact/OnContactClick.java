package customer.smart.support.contact;

public interface OnContactClick {

    void onDeleteClick(int position);

    void onEditClick(int position);
}
