package customer.smart.support.attachment;

public interface ViewClick {
    void onViewClick(int position);
}
