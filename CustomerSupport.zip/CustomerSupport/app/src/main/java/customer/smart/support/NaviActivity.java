package customer.smart.support;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.CardView;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

import customer.smart.support.ad.MainActivityAd;
import customer.smart.support.cmobile.MainActivityMobile;
import customer.smart.support.contact.MainActivityContact;
import customer.smart.support.offer.OfferActivity;
import customer.smart.support.shop.MainActivity;
import customer.smart.support.staff.MainActivityStaff;
import customer.smart.support.stock.MainActivityStock;

public class NaviActivity extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_navi);

        LinearLayout ad = (LinearLayout) findViewById(R.id.ad);
        ad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent io = new Intent(NaviActivity.this, MainActivityAd.class);
                startActivity(io);

            }
        });
        LinearLayout shop = (LinearLayout) findViewById(R.id.shop);
        shop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent io = new Intent(NaviActivity.this, MainActivity.class);
                startActivity(io);

            }
        });

        LinearLayout stock = (LinearLayout) findViewById(R.id.stock);
        stock.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent io = new Intent(NaviActivity.this, MainActivityStock.class);
                startActivity(io);

            }
        });
        LinearLayout staff = (LinearLayout) findViewById(R.id.staff);
        staff.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent io = new Intent(NaviActivity.this, MainActivityStaff.class);
                startActivity(io);

            }
        });
        LinearLayout cmobile = (LinearLayout) findViewById(R.id.cmobile);
        cmobile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent io = new Intent(NaviActivity.this, MainActivityMobile.class);
                startActivity(io);

            }
        });
        LinearLayout offer = (LinearLayout) findViewById(R.id.offer);
        offer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent io = new Intent(NaviActivity.this, OfferActivity.class);
                startActivity(io);

            }
        });

        LinearLayout contact = (LinearLayout) findViewById(R.id.contact);
        contact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent io = new Intent(NaviActivity.this, MainActivityContact.class);
                startActivity(io);

            }
        });
    }
}
