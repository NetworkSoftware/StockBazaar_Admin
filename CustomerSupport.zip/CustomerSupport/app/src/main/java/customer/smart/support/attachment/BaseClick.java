package customer.smart.support.attachment;

public interface BaseClick {
    void onBaseClick(int position);

    void onDeleteClick(int position);
}
