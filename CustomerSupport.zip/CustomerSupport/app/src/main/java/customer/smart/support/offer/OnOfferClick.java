package customer.smart.support.offer;

public interface OnOfferClick {

    void onDeleteClick(int position);

    void onEditClick(int position);
}
