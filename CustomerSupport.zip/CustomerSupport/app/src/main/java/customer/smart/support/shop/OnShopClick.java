package customer.smart.support.shop;

public interface OnShopClick {

    void onDeleteClick(int position);

    void onEditClick(Shop position);
}
