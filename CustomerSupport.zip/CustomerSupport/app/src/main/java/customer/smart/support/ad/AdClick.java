package customer.smart.support.ad;

public interface AdClick {

    void onDeleteClick(int position);
}
